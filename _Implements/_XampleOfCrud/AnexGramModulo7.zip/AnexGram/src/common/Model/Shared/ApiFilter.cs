﻿namespace Model.Shared
{
    public class ApiFilter
    {
        public string Sort { get; set; }
        public bool Descending { get; set; }
        public int Take { get; set; }

        public string Filter { get; set; }

        public ApiFilter()
        {
            Take = 20;
        }
    }
}
