﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaAC.Models
{
    public class Estudiante : Persona
    {
        public string Codigo { get; set; }
    }
}
