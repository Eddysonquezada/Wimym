<template>
  <el-row>
    <el-col :span="10">
      <h1 @click="goTo('/')"><i class="fa fa-camera"></i> AnexGram</h1>
    </el-col>
    <el-col :span="4" class="text-center">
      <el-input placeholder="Buscar .." suffix-icon="fa fa-search"></el-input>
    </el-col>
    <el-col :span="10" class="text-right user-options">
      <a class="item" href="#/mi-informacion">
        <i class="fa fa-user"></i>
        {{ user.Name }}
      </a>
      <a class="item" href="/auth/logout">
        <i class="fa fa-sign-out-alt"></i>
      </a>
      <img class="avatar" v-if="image != null" :src="image" />
    </el-col>
  </el-row>
</template>

<style>
#header {
  height: 60px;
  line-height: 60px;
  background: #fff;
  border-bottom: 1px solid #ccc;
  box-shadow: 0px 0px 15px 0px #eee;
}

#header h1 {
  margin: 0;
}

#header .user-options a{
  color: #222;
  text-decoration: none;
}

#header .user-options .avatar{
  height: 60px;
  float: right;
}

#header .user-options .item {
  font-size: 1.2em;
  padding:5px 15px;
  border-radius:10px;
  margin-right: 5px;
}

#header .user-options .item:hover {
  background:#fff;
}

#header .el-header .user-options .item:last-child {
  margin-right: 0;
}
</style>

<script>
export default {
  name: "TopHeader",
  data: () => ({
    user: window.User
  }),
  methods: {
    goTo(path) {
      if(path === undefined) return;
      this.$router.push(path);
    }
  },
  computed: {
    image() {
      let user = window.User;

      if(user.Image != null && user.Image.length > 0) {
        return `${window.Api.url}uploads/${user.Image}`
      }

      return null;
    }
  }
};
</script>