import Vue from 'vue'
import Router from 'vue-router'

import Default from '@/components/Default'
import UserInfo from '@/components/user/info'

Vue.use(Router)

const routes = [
  { path: '/', name: 'Default', component: Default },
  { path: '/mi-informacion', name: 'UserInfo', component: UserInfo },
]

export default new Router({
  routes
})
