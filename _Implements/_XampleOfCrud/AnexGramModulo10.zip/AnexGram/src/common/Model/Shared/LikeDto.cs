﻿namespace Model.Shared
{
    public class LikeCreateDto
    {
        public string UserId { get; set; }
        public int PhotoId { get; set; }
    }
}
