# anexcore-backoffice

> SPA Base Project using VueJs

## Build Setup

It's a project base for create SPA applications using Vue.

For a detailed explanation on how things work, check out the next [post](http://anexsoft.com/p/186/proyecto-base-spa-con-vue-vuex-vuerouter-axios-y-element-ui?) and follow us.

Development by Anexsoft
