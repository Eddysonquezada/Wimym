﻿namespace VueSpaApplication.Config
{
    public static class SpaParameters
    {
        public static string ApiUrl { get; set; }
    }
}
