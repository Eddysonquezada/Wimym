class UserService {
    axios
    baseUrl

    constructor(axios, baseUrl) {
        this.axios = axios
        this.baseUrl = baseUrl
    }

    get(id) {
        let self = this;
        return self.axios.get(`${self.baseUrl}users/${id}`);
    }

    partial(id, params) {
        let self = this;
        return self.axios.patch(`${self.baseUrl}users/${id}`, params);
    }

    image(id, file) {
        let self = this;
        return self.axios.put(`${self.baseUrl}users/${id}/image`, file);
    }

    refreshClaims() {
        window.location.href = '/auth/refresh';
    }
}

export default UserService