import Axios from 'axios'
import UserService from '../services/UserService'
import FileService from '../services/FileService'

// Axios Configuration
Axios.defaults.headers.common.Accept = 'application/json'
Axios.defaults.headers.common.Authorization = `bearer ${User.Token}`

export default {
    userService: new UserService(Axios, window.Api.url),
    fileService: new FileService(),
}